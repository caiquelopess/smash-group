# -*- coding: utf-8 -*-
"""Limites de memoria de video do MCPE 1.1.5 (evita o jogo fechar ao carregar o pack).

1) Atlas de blocos e de itens: o jogo junta todas as texturas de blocos (e todas as de itens) numa
   imagem so, e usa para TODAS o tamanho da maior. Uma unica textura 512x num pack 32x faz o atlas
   de blocos virar ~11000 px de lado e o jogo fecha. Aqui o tamanho de cada textura do atlas fica
   limitado ao maior que cabe num atlas de 4096 px (16x, 32x e 64x nunca sao mexidos).
2) Animacoes (flipbook: lava, agua, fogo, portal...): a tira de quadros vai inteira para a placa de
   video; mais de 4096 px de altura nao carrega em muitos celulares. Os quadros sao reduzidos ate caber.
Reducao so por fatores inteiros (2x, 4x...), com media dos pixels (fica nitido, sem borrar)."""
import io, json, os
from PIL import Image

LADO_MAX = 4096                 # maior textura garantida nos celulares
ORCAMENTO = LADO_MAX * LADO_MAX * 0.75

def _lado_seguro(n_texturas):
    t = 16
    while n_texturas * (t * 2) ** 2 <= ORCAMENTO: t *= 2
    return t

def _reduzir(dados, nome, fator):
    im = Image.open(io.BytesIO(dados)); modo = im.mode
    im = im.convert('RGBA').resize((max(1, im.size[0] // fator), max(1, im.size[1] // fator)), Image.BOX)
    b = io.BytesIO()
    if nome.endswith('.tga'): im.save(b, format='TGA', rle=False)
    else: im.save(b, format='PNG')
    return b.getvalue()

def limitar(arq, n_blocos, n_itens, prefixo='textures/'):
    """arq: {caminho: bytes} do pack (muda no lugar). Devolve lista de notas para o relatorio."""
    notas = []
    flip = set()
    fj = arq.get(prefixo + 'flipbook_textures.json')
    if fj:
        try: flip = {e['flipbook_texture'] for e in json.loads(fj.decode('utf-8'))}
        except Exception: pass
    for pasta, n in (('blocks', n_blocos), ('items', n_itens)):
        lado = _lado_seguro(n); reduz = []
        for nome in sorted(arq):
            if not nome.startswith(prefixo + pasta + '/') or not nome.endswith(('.png', '.tga')): continue
            try: w, h = Image.open(io.BytesIO(arq[nome])).size
            except Exception: continue
            fator = 1
            while w // fator > lado and (w // fator) % 2 == 0: fator *= 2
            if fator > 1:
                arq[nome] = _reduzir(arq[nome], nome, fator); reduz.append('%s (%dx -> %dx)' % (os.path.basename(nome), w, w // fator))
        if reduz:
            notas.append('atlas de %s: limite seguro %dx (%d texturas no atlas); reduzidas: %s' % (pasta, lado, n, ', '.join(reduz)))
    for base in sorted(flip):
        for ext in ('.png', '.tga'):
            nome = base + ext
            if nome not in arq: continue
            w, h = Image.open(io.BytesIO(arq[nome])).size; fator = 1
            while h // fator > LADO_MAX and (w // fator) % 2 == 0 and w // fator > 16: fator *= 2
            if fator > 1:
                arq[nome] = _reduzir(arq[nome], nome, fator)
                notas.append('animacao %s: %dx%d -> %dx%d (cabe na placa de video)' % (os.path.basename(nome), w, h, w // fator, h // fator))
    return notas

if __name__ == '__main__':
    # conserta um pack 1.1.5 ja convertido:  python limites.py PACK.zip [SAIDA.zip]
    import sys, zipfile
    aqui = os.path.dirname(os.path.abspath(__file__)); bt = os.path.join(aqui, 'base', 'textures')
    ent = sys.argv[1]; sai = sys.argv[2] if len(sys.argv) > 2 else ent[:-4] + ' (corrigido).zip'
    z = zipfile.ZipFile(ent); arq = {n: z.read(n) for n in z.namelist() if not n.endswith('/')}
    for nt in limitar(arq, len(os.listdir(os.path.join(bt, 'blocks'))), len(os.listdir(os.path.join(bt, 'items')))): print(nt)
    with zipfile.ZipFile(sai, 'w') as zo:
        for n in z.namelist():
            if n in arq: zo.writestr(n, arq[n], zipfile.ZIP_STORED if n.endswith('.png') else zipfile.ZIP_DEFLATED)
    print('Salvo:', sai)
