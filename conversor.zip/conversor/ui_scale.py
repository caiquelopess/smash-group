# Ajusta os arquivos de interface (ui/*.json) quando uma textura de interface fica em alta resolucao.
# No MCPE 1.1.5 os campos "uv", "uv_size" e "nineslice_size" sao medidos em pixels da imagem real,
# entao uma gui.png 4x maior precisa desses numeros multiplicados por 4.
import os, json, re, copy

KEYS = ('uv', 'uv_size', 'nineslice_size')

def _load(p):
    s = open(p, encoding='utf-8-sig').read()
    out = []; i = 0; ins = False
    while i < len(s):
        c = s[i]
        if ins:
            out.append(c)
            if c == '\\': out.append(s[i+1]); i += 1
            elif c == '"': ins = False
        else:
            if c == '"': ins = True; out.append(c)
            elif s.startswith('//', i):
                while i < len(s) and s[i] != '\n': i += 1
                continue
            elif s.startswith('/*', i): i = s.index('*/', i) + 2; continue
            else: out.append(c)
        i += 1
    return json.loads(re.sub(r',(\s*[}\]])', r'\1', ''.join(out)))

def _scale(v, k):
    if isinstance(v, (int, float)): return v * k
    if isinstance(v, list) and all(isinstance(x, (int, float)) for x in v): return [x * k for x in v]
    return None  # variavel ou outra coisa

def scale_ui(ui_dir, factors, out_dir):
    """factors: {'textures/gui/gui': 4, ...}. Escreve em out_dir so os arquivos alterados. Devolve (n_alteracoes, avisos)."""
    files = {}; reg = {}; elems = []
    for f in sorted(os.listdir(ui_dir)):
        if not f.endswith('.json'): continue
        try: d = _load(os.path.join(ui_dir, f))
        except Exception: continue
        if not isinstance(d, dict): continue
        files[f] = d; ns = d.get('namespace', '')
        def walk_controls(obj, ns, f):
            for c in obj.get('controls', []) if isinstance(obj.get('controls'), list) else []:
                if isinstance(c, dict):
                    for k, v in c.items():
                        if isinstance(v, dict):
                            elems.append((f, ns, k, v)); walk_controls(v, ns, f)
        for k, v in d.items():
            if k == 'namespace' or not isinstance(v, dict): continue
            name = k.split('@')[0]; reg[(ns, name)] = v
            elems.append((f, ns, k, v)); walk_controls(v, ns, f)
    base_of = {}
    for f, ns, k, v in elems:
        if '@' in k:
            ref = k.split('@', 1)[1]
            bns, bname = ref.split('.', 1) if '.' in ref else (ns, ref)
            base_of[id(v)] = reg.get((bns, bname))
    def eff(obj, key, depth=0):
        if obj is None or depth > 40: return None, None
        if key in obj: return obj[key], obj
        return eff(base_of.get(id(obj)), key, depth + 1)
    def tex_of(obj):
        t, _ = eff(obj, 'texture')
        if isinstance(t, str) and t.startswith('$'):
            # variavel com valor padrao no proprio elemento ou nos modelos
            for kk in (t + '|default',):
                dv, _ = eff(obj, kk)
                if isinstance(dv, str): return dv
            return None
        return t
    acts = []; warn = []
    for f, ns, k, obj in elems:
        t = tex_of(obj); kf = factors.get(t)
        for key in KEYS:
            v, owner = eff(obj, key)
            if v is None: continue
            ot = tex_of(owner) if owner is not None else None
            if kf:
                if owner is obj or factors.get(ot) == kf:
                    if owner is obj: acts.append((f, obj, key, v, kf))
                else:
                    acts.append((f, obj, key, v, kf))  # herdado de modelo com outra textura: copia ja ajustado
            else:
                if owner is not obj and factors.get(ot):
                    acts.append((f, obj, key, v, 1))  # herdado de modelo ajustado: fixa o valor original
    changed = set(); n = 0; varscale = {}
    for f, obj, key, v, kf in acts:
        if isinstance(v, str) and v.startswith('$') and kf != 1:
            varscale.setdefault(f, {})[v] = kf; continue
        sv = _scale(v, kf)
        if sv is None:
            warn.append('%s: %s=%r (nao ajustado)' % (f, key, v)); continue
        obj[key] = sv if kf != 1 else copy.deepcopy(v); changed.add(f); n += 1
    # variaveis ($image_uv...) usadas por imagens ajustadas: ajusta onde recebem valor, no mesmo arquivo
    def fix_vars(o, vs, f):
        nonlocal n
        if isinstance(o, dict):
            for kk in list(o.keys()):
                base = kk.split('|')[0]
                if base in vs:
                    sv = _scale(o[kk], vs[base])
                    if sv is not None: o[kk] = sv; changed.add(f); n += 1
                    else: warn.append('%s: %s=%r (nao ajustado)' % (f, kk, o[kk]))
                else: fix_vars(o[kk], vs, f)
        elif isinstance(o, list):
            for x in o: fix_vars(x, vs, f)
    for f, vs in varscale.items(): fix_vars(files[f], vs, f)
    os.makedirs(out_dir, exist_ok=True)
    for f in changed:
        json.dump(files[f], open(os.path.join(out_dir, f), 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
    return n, sorted(changed), warn

if __name__ == '__main__':
    import sys
    n, ch, w = scale_ui(sys.argv[1], {'textures/gui/gui': 4, 'textures/gui/icons': 4}, sys.argv[2])
    print(n, ch); print('\n'.join(w))
