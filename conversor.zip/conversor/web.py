# Ponte entre a pagina (worker) e o converter.py
import io, os, re, json, base64, zipfile, contextlib, shutil
import converter as CV
from PIL import Image

def _find(z, suffix):
    c = [n for n in z.namelist() if n.lower().endswith(suffix)]
    return min(c, key=len) if c else None

def inspecionar(path):
    z = zipfile.ZipFile(path); info = {'nome': os.path.splitext(os.path.basename(path))[0], 'descricao': '',
                                       'formato': None, 'icone': None, 'resolucao': None, 'arquivos': len(z.namelist()), 'bedrock': False}
    m = _find(z, 'pack.mcmeta')
    if m:
        try:
            j = json.loads(z.read(m).decode('utf-8-sig', 'ignore')); p = j.get('pack', {})
            info['formato'] = p.get('pack_format'); d = p.get('description', '')
            if isinstance(d, dict): d = d.get('text', '')
            if isinstance(d, list): d = ''.join(x if isinstance(x, str) else x.get('text', '') for x in d)
            info['descricao'] = str(d)
        except Exception: pass
    elif _find(z, 'manifest.json'): info['bedrock'] = True
    ic = _find(z, 'pack.png')
    if ic:
        try:
            im = Image.open(io.BytesIO(z.read(ic))).convert('RGBA'); im.thumbnail((128, 128), Image.NEAREST)
            b = io.BytesIO(); im.save(b, 'PNG'); info['icone'] = base64.b64encode(b.getvalue()).decode()
        except Exception: pass
    for alvo in ('textures/blocks/stone.png', 'textures/block/stone.png', 'textures/blocks/dirt.png', 'textures/items/diamond_sword.png'):
        s = _find(z, alvo)
        if s:
            try: info['resolucao'] = Image.open(io.BytesIO(z.read(s))).size[0]; break
            except Exception: pass
    return json.dumps(info)

def converter(path, saida='/work/out'):
    shutil.rmtree(saida, ignore_errors=True); os.makedirs(saida)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        mcpack, pasta = CV.converter(path, saida)
    log = buf.getvalue()
    # pack em .zip COM a pasta do pack dentro (o 1.1.5 nao importa .mcpack):
    # extrair em games/com.mojang/resource_packs/ -> resource_packs/NOME_MCPE_1.1.5/manifest.json
    topo = os.path.basename(pasta.rstrip('/'))
    pz = os.path.join(saida, topo + '.zip')
    with zipfile.ZipFile(pz, 'w', zipfile.ZIP_DEFLATED) as Z:
        for r, _, fs in os.walk(pasta):
            for f in fs:
                p = os.path.join(r, f); Z.write(p, os.path.join(topo, os.path.relpath(p, pasta)))
    rel = [os.path.join(saida, f) for f in os.listdir(saida) if f.endswith('_relatorio.txt')]
    m = re.search(r'Convertidas: (\d+)', log); cats = dict((a, int(b)) for a, b in re.findall(r'^  ([\w/]+): (\d+)$', log, re.M))
    avisos = re.findall(r'^AVISO: (.*)$', log, re.M)
    return json.dumps({'pack': pz, 'pasta': topo, 'relatorio': rel[0] if rel else None,
                       'total': int(m.group(1)) if m else None, 'categorias': cats, 'avisos': avisos, 'log': log})
