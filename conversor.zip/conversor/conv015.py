# -*- coding: utf-8 -*-
"""Leva o pack ja convertido para o MCPE 1.1.5 (na memoria) para o formato do MCPE 0.15.10.

A 0.15 guarda o pack como a pasta assets/resourcepacks/vanilla do APK:
  resources.json (nome logico -> arquivo), images/... (blocks, items, mob, entity, item, armor, art...)
O resultado e a pasta vanilla da 0.15 COMPLETA, com as texturas do pack no lugar das originais
(o que o pack nao tem continua o da 0.15)."""
import io, os, json
from PIL import Image

# nomes que mudaram da 0.15 para a 1.1.5 (caminho sem extensao, relativo a images/ -> textures/)
EXPLICITO = {
    'mob/skeleton': 'entity/skeleton/skeleton', 'mob/wither_skeleton': 'entity/skeleton/wither_skeleton',
    'mob/zombie': 'entity/zombie/zombie', 'mob/slime': 'entity/slime/slime', 'mob/creeper': 'entity/creeper/creeper',
    'items/bed': 'items/bed_red', 'item/tripod_camera': 'entity/camera_tripod',
    'blocks/sandstone_side': 'blocks/sandstone_normal', 'blocks/water': 'blocks/water_still', 'blocks/lava': 'blocks/lava_still',
    'blocks/fire_layer_0': 'blocks/fire_0', 'blocks/fire_layer_1': 'blocks/fire_1', 'fire_layer_0': 'blocks/fire_0',
    'cauldron_still': 'blocks/cauldron_water',
}
for i in range(4): EXPLICITO['blocks/beetroot_stage_%d' % i] = 'blocks/beetroots_stage_%d' % i

def _candidatos(rest):
    stem = os.path.splitext(rest)[0]; d = rest.split('/')[0] if '/' in rest else ''
    c = []
    if stem in EXPLICITO: c.append(EXPLICITO[stem])
    if rest == 'particles.png': c.append('particle/particles')
    elif d == 'art': c.append('painting/' + os.path.basename(stem))
    elif d == 'armor': c.append('models/armor/' + os.path.basename(stem))
    elif d in ('mob', 'item'): c.append('entity/' + stem.split('/', 1)[1])
    elif d: c.append(stem)
    else: c.append('blocks/' + stem)
    return c

def _abrir(b): return Image.open(io.BytesIO(b))

def _adaptar(im, ref):
    """deixa a textura do pack no formato que a 0.15 espera (proporcao do original da 0.15)"""
    w, h = im.size; rw, rh = ref.size
    if w * rh == h * rw: return im
    if rw == rh and h > w and h % w == 0: return im.crop((0, 0, w, w))          # animada -> 1o quadro
    if rw == 2 * rh and w == h: return im.crop((0, 0, w, w // 2))               # skin 64x64 -> 64x32 (metade de cima)
    return None

def montar(arq115, base015, titulo, desc):
    """arq115: {'textures/...': bytes} do pack 1.1.5. Devolve ({caminho: bytes} da 0.15, trocadas, puladas)"""
    saida = {}
    for dp, _, fs in os.walk(base015):
        for f in fs:
            p = os.path.join(dp, f); saida[os.path.relpath(p, base015).replace('\\', '/')] = open(p, 'rb').read()
    tex = {}
    for k in arq115:
        if k.startswith('textures/'): tex.setdefault(os.path.splitext(k[len('textures/'):])[0], k)
    porstem = {}
    for s in tex: porstem.setdefault(os.path.basename(s).lower(), []).append(s)
    trocadas, puladas = [], []
    for rel in sorted(saida):
        if not rel.startswith('images/') or not rel.endswith(('.png', '.tga')): continue
        rest = rel[len('images/'):]
        achou = next((tex[c] for c in _candidatos(rest) if c in tex), None)
        if achou is None:
            st = os.path.splitext(os.path.basename(rest))[0].lower()
            if len(porstem.get(st, [])) == 1: achou = tex[porstem[st][0]]
        if achou is None: continue
        try:
            ref = _abrir(saida[rel]); im = _abrir(arq115[achou]).convert('RGBA')
        except Exception:
            puladas.append(rel); continue
        im2 = _adaptar(im, ref)
        if im2 is None: puladas.append(rel); continue
        b = io.BytesIO()
        if rel.endswith('.tga'): im2.save(b, format='TGA', rle=False)
        else: im2.save(b, format='PNG')
        saida[rel] = b.getvalue(); trocadas.append(rel)
    if 'pack_icon.png' in arq115: saida['pack_icon.png'] = arq115['pack_icon.png']
    try:
        r = json.loads(saida['resources.json'].decode('utf-8-sig'))
        r['name'] = titulo + ' - 0.15.10'; r['description'] = desc
        saida['resources.json'] = json.dumps(r, indent=2, ensure_ascii=False).encode('utf-8')
    except Exception:
        pass
    return saida, trocadas, puladas
