#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Conversor de resource packs Minecraft Java 1.8.9 -> Minecraft PE / Bedrock 1.1.5  (SEM REDUZIR AS IMAGENS)

Uso:  python converter.py PACK_JAVA.zip|PASTA [PASTA_DE_SAIDA] [--015]
      (--015 gera para o MCPE 0.15.10; sem ele, MCPE 1.1.5)

Toda textura do pack vai na resolucao original dela (nada e reduzido nem borrado).
Quando o Bedrock precisa juntar a textura do pack com uma parte que so existe nele,
a parte do Bedrock e que e ampliada (pixel por pixel, sem perder nitidez).

Saida (em PASTA_DE_SAIDA):
  NOME_MCPE_1.1.5.zip      -> o pack ja empacotado (manifest.json na raiz do zip): coloque o .zip
                              em games/com.mojang/resource_packs/ (o 1.1.5 nao abre .mcpack)
  NOME_relatorio.txt       -> o que foi convertido e o que ficou original

Opcional:  --aplicar PASTA_DO_JOGO   copia o resultado direto para PASTA_DO_JOGO/assets/resource_packs/vanilla
"""
import os, sys, io, re, json, uuid, shutil, zipfile, tempfile
import numpy as np
from PIL import Image, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ui_scale import scale_ui, _load as jsonc

BASE = os.path.join(HERE, 'base')
BT = os.path.join(BASE, 'textures')

# ------------------------------------------------------------------ utilitarios
def rgba(p): return Image.open(p).convert('RGBA')
def arr(im): return np.asarray(im.convert('RGBA')).astype(np.float32)
def arr8(im): return np.array(im.convert('RGBA'))   # uint8: 8x menos memoria (folhas grandes, so copia celulas)
def img(a):
    if a.dtype == np.uint8: return Image.fromarray(a, 'RGBA')
    return Image.fromarray(np.clip(a, 0, 255).round().astype('uint8'), 'RGBA')
def up(im, size):
    """amplia sem perda (vizinho mais proximo). Nunca reduz: se pedirem menor, devolve como esta."""
    size = (int(size[0]), int(size[1]))
    if im.size == size or size[0] < im.size[0]: return im
    return im.resize(size, Image.NEAREST)
def match(a, b):
    """deixa duas imagens do mesmo tamanho ampliando a menor"""
    if a.size[0] >= b.size[0]: return a, up(b, (a.size[0], a.size[0] * b.size[1] // b.size[0]))
    return up(a, (b.size[0], b.size[0] * a.size[1] // a.size[0])), b
class Pacote:
    """Saida do pack direto na memoria (nada vai para pasta): no fim vira um .zip de uma vez so."""
    def __init__(self, raiz): self.raiz = raiz; self.arq = {}
    def rel(self, path): return os.path.relpath(path, self.raiz).replace('\\', '/')
    def dentro(self, path): return not os.path.relpath(path, self.raiz).startswith('..')
    def put(self, path, data): self.arq[self.rel(path)] = data
    def tem(self, path): return self.rel(path) in self.arq
    def tamanho(self, path): return Image.open(io.BytesIO(self.arq[self.rel(path)])).size
    def gravar_zip(self, z):
        ordem = sorted(self.arq, key=lambda n: (n not in ('manifest.json', 'pack_icon.png'), n))
        with zipfile.ZipFile(z, 'w') as zf:
            for n in ordem:  # PNG ja e comprimido: vai direto; texto/TGA comprime
                zf.writestr(n, self.arq[n], zipfile.ZIP_STORED if n.endswith('.png') else zipfile.ZIP_DEFLATED)
PACOTE = None
def save(im, path):
    if PACOTE is not None and PACOTE.dentro(path):
        b = io.BytesIO()
        if path.endswith('.tga'): im.convert('RGBA').save(b, format='TGA', rle=False)
        else: im.save(b, format='PNG')
        PACOTE.put(path, b.getvalue()); return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if path.endswith('.tga'): im.convert('RGBA').save(path, format='TGA', rle=False)
    else: im.save(path, format='PNG')  # PNG e sem perda
def mean_rgb(a, m):
    return a[..., :3][m].mean(0) if m.sum() else np.array([255., 255., 255.])
def sat(a, m):
    if m.sum() == 0: return 0
    c = a[..., :3][m]; return float(((c.max(1) - c.min(1)) / (c.max(1) + 1)).mean())
def tint(im, mul):
    a = arr(im); a[..., :3] *= np.asarray(mul)[None, None, :]; return img(a)
def bfile(d, name):
    for e in ('.png', '.tga'):
        p = os.path.join(d, name + e)
        if os.path.exists(p): return p
def same_aspect(a, b): return a.size[0] * b.size[1] == a.size[1] * b.size[0]
def first_frame(im):
    w, h = im.size
    return im.crop((0, 0, w, w)) if h > w and h % w == 0 else im

COL = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'silver', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black']

# nomes Bedrock -> nome no Java 1.8 (so os que mudam)
BALIAS = {'fire_0': 'fire_layer_0', 'fire_1': 'fire_layer_1', 'cauldron_water': 'water_still',
          'water_placeholder': 'water_still', 'lava_placeholder': 'lava_still', 'portal_placeholder': 'portal',
          'cauldron_water_placeholder': 'water_still', 'fire_0_placeholder': 'fire_layer_0', 'fire_1_placeholder': 'fire_layer_1',
          'grass_side_snowed': 'grass_side_snowed', 'command_block': 'command_block'}
EALIAS = {'cat/blackcat': 'cat/black', 'chest/double_normal': 'chest/normal_double', 'chest/trapped_double': 'chest/trapped_double',
          'dragon/dragon': 'enderdragon/dragon', 'dragon/dragon_exploding': 'enderdragon/dragon_exploding',
          'dragon/dragon_eyes': 'enderdragon/dragon_eyes', 'snow_golem': 'snowman', 'pig/pigzombie': 'zombie_pigman',
          'wither_boss/wither': 'wither/wither', 'wither_boss/wither_armor': 'wither/wither_armor',
          'wither_boss/wither_invulnerable': 'wither/wither_invulnerable', 'zombie_villager/zombie_villager': 'zombie/zombie_villager',
          'rabbit/blackrabbit': 'rabbit/black', 'arrows': 'arrow', 'skulls/zombie': 'zombie/zombie', 'skulls/skeleton': 'skeleton/skeleton',
          'skulls/wither_skeleton': 'skeleton/wither_skeleton', 'skulls/creeper': 'creeper/creeper', 'iron_golem': 'iron_golem',
          'endercrystal/endercrystal': 'endercrystal/endercrystal', 'endercrystal/endercrystal_beam': 'endercrystal/endercrystal_beam'}
ARMOR = {'chain_1': 'chainmail_layer_1', 'chain_2': 'chainmail_layer_2', 'cloth_1': 'leather_layer_1', 'cloth_2': 'leather_layer_2',
         'iron_1': 'iron_layer_1', 'iron_2': 'iron_layer_2', 'diamond_1': 'diamond_layer_1', 'diamond_2': 'diamond_layer_2',
         'gold_1': 'gold_layer_1', 'gold_2': 'gold_layer_2'}
IALIAS = {'boat_oak': 'boat', 'lever': '../blocks/lever', 'bed_red': 'bed'}
POTION_ICON = {'speed': (0, 0), 'slowness': (1, 0), 'haste': (2, 0), 'mining_fatigue': (3, 0), 'strength': (4, 0), 'weakness': (5, 0),
               'poison': (6, 0), 'regeneration': (7, 0), 'invisibility': (0, 1), 'hunger': (1, 1), 'jump_boost': (2, 1), 'nausea': (3, 1),
               'night_vision': (4, 1), 'blindness': (5, 1), 'resistance': (6, 1), 'fire_resistance': (7, 1), 'water_breathing': (0, 2),
               'wither': (1, 2), 'absorption': (2, 2), 'health_boost': (7, 2)}

def skin_64x64(old):
    u = old.size[0] // 64; n = Image.new('RGBA', (64 * u, 64 * u)); n.paste(old, (0, 0))
    def face(sx, sy, w, h, dx, dy):
        n.paste(old.crop((sx*u, sy*u, (sx+w)*u, (sy+h)*u)).transpose(Image.FLIP_LEFT_RIGHT), (dx*u, dy*u))
    for (sx, sy), (dx, dy) in (((0, 16), (16, 48)), ((40, 16), (32, 48))):
        face(sx+4, sy, 4, 4, dx+4, dy); face(sx+8, sy, 4, 4, dx+8, dy)
        face(sx+8, sy+4, 4, 12, dx, dy+4); face(sx+4, sy+4, 4, 12, dx+4, dy+4)
        face(sx, sy+4, 4, 12, dx+8, dy+4); face(sx+12, sy+4, 4, 12, dx+12, dy+4)
    return n

def achar_raiz(entrada, tmp):
    if os.path.isfile(entrada):
        with zipfile.ZipFile(entrada) as z:
            for i in z.infolist():
                n = i.filename.replace('\\', '/')
                if n.startswith('/') or '..' in n.split('/'): continue  # zip malicioso
                z.extract(i, tmp)
        entrada = tmp
    for r, ds, _ in os.walk(entrada):
        if r.replace('\\', '/').endswith('assets/minecraft/textures'): return os.path.dirname(r)
    raise SystemExit('Nao achei assets/minecraft/textures dentro do pack.')

def converter(entrada, saida, titulo=None, alvo='1.1.5'):
    titulo = titulo or os.path.splitext(os.path.basename(entrada.rstrip('/\\')))[0] or 'pack'
    nome = re.sub(r'[^A-Za-z0-9_.-]+', '_', titulo) or 'pack'
    # nome do arquivo: "{titulo original} - {versao}" (sem codigos de cor nem caracteres proibidos)
    titulo_arq = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', '_', re.sub('\u00a7.', '', titulo)).strip(' .') or 'pack'
    tmp = tempfile.mkdtemp(); raiz = achar_raiz(entrada, tmp)
    J = os.path.join(raiz, 'textures'); JM = os.path.join(raiz, 'mcpatcher')
    global PACOTE
    OUT = os.path.join(saida, nome + '_MCPE_1.1.5')   # raiz do pack (so virtual: tudo vai para o zip)
    OT = os.path.join(OUT, 'textures'); PACOTE = PK = Pacote(OUT)
    done = []; notas = []
    def mark(rel): done.append(rel)
    def jp(rel):
        p = os.path.join(J, rel + '.png')
        return p if os.path.exists(p) else None
    def jimg(rel, ff=True):
        p = jp(rel)
        if not p: return None
        im = rgba(p); return first_frame(im) if ff else im
    def mcmeta(rel):
        try: return jsonc(os.path.join(J, rel + '.png.mcmeta')).get('animation', {})
        except Exception: return None
    def out_path(rel_with_ext): return os.path.join(OT, rel_with_ext)
    def put(base_path, im, rel_dir):
        dst = os.path.join(OT, rel_dir, os.path.basename(base_path)); save(im, dst); mark(rel_dir + '/' + os.path.basename(base_path))

    # =========================================================== BLOCOS
    basebd = os.path.join(BT, 'blocks')
    fb = jsonc(os.path.join(BT, 'flipbook_textures.json')); fbmap = {os.path.basename(e['flipbook_texture']): e for e in fb}
    terrain = jsonc(os.path.join(BT, 'terrain_texture.json'))['texture_data']
    path2tile = {}
    for k, x in terrain.items():
        L = x['textures']; L = L if isinstance(L, list) else [L]
        for q in L:
            q = q['path'] if isinstance(q, dict) else q
            path2tile.setdefault(q, []).append((k, len(L)))
    new = {}
    for fn in sorted(os.listdir(basebd)):
        s, ext = os.path.splitext(fn)
        if ext not in ('.png', '.tga') or s in ('grass_side', 'grass_side_carried'): continue
        jn = BALIAS.get(s, s)
        if not jp('blocks/' + jn) and '_silver' in jn: jn = jn.replace('_silver', '_light_gray')
        if not jp('blocks/' + jn): continue
        full = rgba(jp('blocks/' + jn)); w, h = full.size; anim = h > w and h % w == 0
        b = rgba(os.path.join(basebd, fn))
        if s.endswith('_placeholder') or s.endswith('_mipmap'):
            out = first_frame(full)
        elif s in fbmap and anim:
            e = fbmap[s]; m = mcmeta('blocks/' + jn) or {}
            fr = m.get('frames')
            if fr: e['frames'] = [x['index'] if isinstance(x, dict) else x for x in fr]
            else: e.pop('frames', None)
            if 'frametime' in m: e['ticks_per_frame'] = m['frametime']
            out = full
        elif anim:
            m = mcmeta('blocks/' + jn); tiles = path2tile.get('textures/blocks/' + s, [])
            if m is not None and len(tiles) == 1 and tiles[0][1] == 1 and s not in fbmap:
                # textura animada no pack que o Bedrock nao anima: cria a animacao
                e = {'flipbook_texture': 'textures/blocks/' + s, 'atlas_tile': tiles[0][0], 'ticks_per_frame': m.get('frametime', 1)}
                fr = m.get('frames')
                if fr: e['frames'] = [x['index'] if isinstance(x, dict) else x for x in fr]
                fb.append(e); fbmap[s] = e; out = full; notas.append('animacao do pack ativada: ' + s)
            else:
                out = first_frame(full)
        else:
            out = full
            if s in fbmap: fbmap[s].pop('frames', None)
        # agua: o Java guarda cinza e o Bedrock 1.1.5 espera azul
        bb = arr(first_frame(b)); oo = arr(first_frame(out))
        if sat(bb, bb[..., 3] > 0) > 0.25 and sat(oo, oo[..., 3] > 0) < 0.08:
            mul = mean_rgb(bb, bb[..., 3] > 0) / np.maximum(mean_rgb(oo, oo[..., 3] > 0), 1)
            out = tint(out, mul); notas.append('cor aplicada (textura cinza no Java): ' + s)
        if ext == '.tga' and s == 'grass_side_snowed':
            a = arr(out); a[..., 3] = 0; out = img(a)
        save(out, out_path('blocks/' + fn)); mark('blocks/' + fn); new[s] = first_frame(out)

    # lado da grama: .png = so a franja (pintada pelo bioma); .tga = terra + franja, alfa = onde pinta
    side = jimg('blocks/grass_side'); ov = jimg('blocks/grass_side_overlay')
    if side and ov:
        side, ov = match(side, ov)
        if os.path.exists(os.path.join(basebd, 'grass_side.png')): save(ov, out_path('blocks/grass_side.png')); mark('blocks/grass_side.png')
        comp = side.copy(); comp.alpha_composite(ov)
        a = arr(comp); a[..., 3] = np.where(arr(ov)[..., 3] > 0, 255, 0)
        if os.path.exists(os.path.join(basebd, 'grass_side.tga')): save(img(a), out_path('blocks/grass_side.tga')); mark('blocks/grass_side.tga')
        bt = arr(rgba(bfile(basebd, 'grass_top'))); bc = arr(rgba(bfile(basebd, 'grass_carried')))
        mul = mean_rgb(bc, bc[..., 3] > 0) / np.maximum(mean_rgb(bt, bt[..., 3] > 0), 1)
        car = side.copy(); car.alpha_composite(tint(ov, mul))
        p = bfile(basebd, 'grass_side_carried')
        if p: save(car, out_path('blocks/' + os.path.basename(p))); mark('blocks/' + os.path.basename(p))

    def fill_holes(im, ratio):
        a = arr(im); pm = a.copy(); pm[..., :3] *= a[..., 3:] / 255; rad = max(1, im.size[0] // 8)
        brgb = np.asarray(img(pm).filter(ImageFilter.GaussianBlur(rad))).astype(np.float32)
        ba = np.asarray(Image.fromarray(a[..., 3].astype('uint8')).filter(ImageFilter.GaussianBlur(rad))).astype(np.float32)
        fill = brgb[..., :3] * 255 / np.maximum(ba, 1)[..., None] * np.asarray(ratio)[None, None, :]
        h = a[..., 3] < 128; a[..., :3][h] = fill[h]; a[..., 3] = 255
        return img(a)
    # icones do inventario (ja coloridos)
    CAR = {'grass_carried': 'grass_top', 'tallgrass_carried': 'tallgrass', 'fern_carried': 'fern', 'vine_carried': 'vine',
           'double_plant_fern_carried': 'double_plant_fern_top', 'double_plant_grass_carried': 'double_plant_grass_top', 'carried_waterlily': 'waterlily'}
    for w in ('acacia', 'big_oak', 'birch', 'jungle', 'oak', 'spruce'): CAR['leaves_%s_carried' % w] = 'leaves_' + w
    for c, g in CAR.items():
        pc = bfile(basebd, c); pg = bfile(basebd, g)
        if not (pc and pg and g in new): continue
        if jp('blocks/' + c): continue  # o pack ja tem a sua
        go = arr(rgba(pg)); co = arr(rgba(pc))
        mul = np.minimum(3, (mean_rgb(co, co[..., 3] > 0) + 1) / (mean_rgb(go, go[..., 3] > 0) + 1))
        out = tint(new[g], mul)
        if rgba(pc).getextrema()[3][0] == 255:
            hole = go[..., 3] < 128; out = fill_holes(out, (mean_rgb(co, hole) + 1) / (mean_rgb(co, ~hole) + 1))
        save(out, out_path('blocks/' + os.path.basename(pc))); mark('blocks/' + os.path.basename(pc))
    for w in ('acacia', 'big_oak', 'birch', 'jungle', 'oak', 'spruce'):
        po = bfile(basebd, 'leaves_%s_opaque' % w); pl = bfile(basebd, 'leaves_' + w)
        if not (po and pl and ('leaves_' + w) in new) or jp('blocks/leaves_%s_opaque' % w): continue
        bo = arr(rgba(po)); bl = arr(rgba(pl)); hole = bl[..., 3] < 128
        save(fill_holes(new['leaves_' + w], (mean_rgb(bo, hole) + 1) / (mean_rgb(bl, ~hole) + 1)), out_path('blocks/' + os.path.basename(po)))
        mark('blocks/' + os.path.basename(po))
    # redstone: confere a direcao da linha com a do Bedrock (horizontal)
    def oriented(im, ref_name):
        ref = rgba(bfile(basebd, ref_name)); r = arr(up(ref, im.size))[..., 3] > 0
        a = arr(im)[..., 3] > 0; b = arr(im.rotate(90))[..., 3] > 0
        return im if (a & r).sum() >= (b & r).sum() else im.rotate(90)
    if jp('blocks/redstone_dust_line') and 'redstone_dust_line' in new:
        save(oriented(jimg('blocks/redstone_dust_line'), 'redstone_dust_line'), out_path('blocks/redstone_dust_line.png'))
        mark('blocks/redstone_dust_line.png')
    elif jp('blocks/redstone_dust_line0'):
        l0 = jimg('blocks/redstone_dust_line0'); line = oriented(l0, 'redstone_dust_line')
        save(line, out_path('blocks/redstone_dust_line.png')); mark('blocks/redstone_dust_line.png')
        if not jp('blocks/redstone_dust_cross') and jp('blocks/redstone_dust_dot'):
            dot, l0 = match(jimg('blocks/redstone_dust_dot'), l0)
            cross = l0.copy(); cross.alpha_composite(l0.rotate(90)); cross.alpha_composite(dot)
            save(cross, out_path('blocks/redstone_dust_cross.png')); mark('blocks/redstone_dust_cross.png')

    # =========================================================== ENTIDADES
    basee = os.path.join(BT, 'entity')
    def ebase(key): return bfile(basee, key)
    def eput(key, im):
        p = ebase(key); dst = os.path.join(OT, 'entity', os.path.relpath(p, basee))
        if p.endswith('.tga'):  # mantem a mascara especial do alfa (olhos que brilham, area pintavel)
            ba = arr(rgba(p).resize(im.size, Image.NEAREST))[..., 3]; a = arr(im); a[..., 3] = ba; im = img(a)
        save(im, dst); mark('entity/' + os.path.relpath(p, basee).replace('\\', '/'))
    for root, _, fs in os.walk(basee):
        for fn in sorted(fs):
            key = os.path.splitext(os.path.relpath(os.path.join(root, fn), basee).replace('\\', '/'))[0]
            if key in ('sheep/sheep', 'wolf/wolf_tame'): continue
            jrel = EALIAS.get(key, key); j = jimg('entity/' + jrel, ff=False)
            if j is None: continue
            bo = Image.open(os.path.join(root, fn))
            if key in ('zombie/zombie', 'zombie/husk', 'skulls/zombie', 'pig/pigzombie') and j.size[0] == j.size[1] and bo.size[0] == 2 * bo.size[1]:
                j = j.crop((0, 0, j.size[0], j.size[0] // 2))  # 64x64 -> metade de cima (mesmo desenho do 64x32)
            if key == 'arrows':
                # Bedrock: flecha normal (linhas 0-10 de 32) + flecha com efeito (10-20): copia a normal e pinta a haste
                b = arr(up(rgba(ebase(key)), j.size)); a = arr(j); s = j.size[0] / 32; t0, t1 = int(10 * s), int(20 * s)
                o = b.copy(); o[:t0] = a[:t0]; top = a[:t0].copy()
                bt_, bn = b[t0:t1], b[:t0]
                diff = (np.abs(bt_[..., :3] - bn[..., :3]).sum(-1) > 30) & (bt_[..., 3] > 0)
                top[..., :3][diff] *= mean_rgb(bt_, diff) / np.maximum(mean_rgb(bn, diff), 1)
                if a.shape[0] >= t1 and (a[t0:t1, ..., 3] > 0).any(): o[t0:t1] = a[t0:t1]
                else: o[t0:t1] = top
                eput(key, img(o)); continue
            if key in ('steve', 'alex') and j.size[0] == 2 * j.size[1] and bo.size[0] == bo.size[1]:
                j = skin_64x64(j)  # skin antiga 64x32 -> formato 64x64 (espelha braco e perna)
            if not same_aspect(j, bo):
                notas.append('mob com formato diferente, ficou original: ' + key); continue
            eput(key, j)
    sh = jimg('entity/sheep/sheep'); fur = jimg('entity/sheep/sheep_fur')
    if sh and ebase('sheep/sheep'):
        W, H = sh.size; c = Image.new('RGBA', (W, H * 2)); c.paste(sh, (0, 0))
        if fur: c.paste(up(fur, (W, H)) if fur.size[0] <= W else fur.resize((W, H), Image.NEAREST), (0, H))
        else: c.paste(up(rgba(ebase('sheep/sheep')), (W, 2 * H)).crop((0, H, W, 2 * H)), (0, H))
        eput('sheep/sheep', c)
    wt = jimg('entity/wolf/wolf_tame'); col = jimg('entity/wolf/wolf_collar')
    if wt and ebase('wolf/wolf_tame'):
        if col:
            wt, col = match(wt, col); comp = wt.copy(); comp.alpha_composite(col)
            a = arr(comp); a[..., 3] = np.where(arr(col)[..., 3] > 0, 255, 0)
            save(img(a), os.path.join(OT, 'entity', os.path.relpath(ebase('wolf/wolf_tame'), basee))); mark('entity/wolf/wolf_tame')
        else: eput('wolf/wolf_tame', wt)
    # baus como bloco (icone do inventario no Bedrock)
    def chest_block(ent, basename, knob=True, part='front'):
        p = bfile(basebd, basename)
        if not (p and ent): return
        k = ent.size[0] / 64; E = arr(ent)
        R = lambda x0, y0, x1, y1: E[int(y0*k):int(y1*k), int(x0*k):int(x1*k)]
        face = {'front': np.concatenate([R(14, 14, 28, 19), R(14, 33, 28, 42)], 0),
                'side': np.concatenate([R(0, 14, 14, 19), R(0, 33, 14, 42)], 0), 'top': R(14, 0, 28, 14)}[part]
        S = max(16, int(round(16 * k))); s = S / 16
        out = arr(up(rgba(p), (S, S)))
        out[int(s):int(15*s), int(s):int(15*s)] = np.asarray(img(face).resize((int(14*s), int(14*s)), Image.NEAREST)).astype(np.float32)
        if knob and part == 'front':
            kn = np.asarray(img(R(1, 1, 3, 5)).resize((int(2*s), int(4*s)), Image.NEAREST)).astype(np.float32)
            y, x = int(3*s), int(7*s); reg = out[y:y+kn.shape[0], x:x+kn.shape[1]]
            out[y:y+kn.shape[0], x:x+kn.shape[1]] = np.where(kn[..., 3:] > 0, kn, reg)
        save(img(out), out_path('blocks/' + os.path.basename(p))); mark('blocks/' + os.path.basename(p))
    cn = jimg('entity/chest/normal'); ct = jimg('entity/chest/trapped'); ce = jimg('entity/chest/ender')
    for part in ('front', 'side', 'top'): chest_block(cn, 'chest_' + part, part=part); chest_block(ce, 'ender_chest_' + part, part=part)
    chest_block(ct, 'trapped_chest_front')
    # armaduras
    adir = os.path.join(BT, 'models/armor')
    for k_, jn in ARMOR.items():
        p = bfile(adir, k_); j = jimg('models/armor/' + jn)
        if p and j and same_aspect(j, Image.open(p)): put(p, j, 'models/armor')
    for n in ('1', '2'):
        p = bfile(adir, 'leather_' + n); g = jimg('models/armor/leather_layer_' + n); ov = jimg('models/armor/leather_layer_%s_overlay' % n)
        if p and g:
            if ov: g, ov = match(g, ov)
            comp = g.copy()
            if ov: comp.alpha_composite(ov)
            a = arr(comp); ga = arr(g)[..., 3] > 0; oa = arr(ov)[..., 3] > 0 if ov else np.zeros(ga.shape, bool)
            a[..., 3] = np.where(oa, 1, np.where(ga, 255, 0)); put(p, img(a), 'models/armor')

    # =========================================================== ITENS (resolucao do pack)
    basei = os.path.join(BT, 'items')
    def jitem(name):
        rel = IALIAS.get(name, name)
        return jimg('blocks/' + rel[10:]) if rel.startswith('../blocks/') else jimg('items/' + rel)
    def limpa_item(im, name):
        # Na 1.1.5 o item na mao e montado em 3D com todo pixel que tem um minimo de alfa.
        # Pixels quase invisiveis (sobra de edicao, alfa < 32 de 255) viram uma "aura" solida em volta do item.
        # Eles nao aparecem na hotbar, entao apagar nao muda o visual do icone.
        a = np.asarray(im).copy(); lixo = (a[..., 3] > 0) & (a[..., 3] < 32)
        if lixo.any():
            a[lixo] = 0; im = Image.fromarray(a, 'RGBA')
            if lixo.sum() > 50: notas.append('item %s: %d pixels quase invisiveis removidos (evita borda em volta do item na mao)' % (name, lixo.sum()))
        meio = (a[..., 3] >= 32) & (a[..., 3] < 255); vis = a[..., 3] > 0
        if vis.sum() and meio.sum() > 0.2 * vis.sum():
            notas.append('AVISO item %s: tem brilho semitransparente; na mao pode aparecer como borda' % name)
        return im
    special = set()
    for fn in sorted(os.listdir(basei)):
        s, ext = os.path.splitext(fn)
        if ext not in ('.png', '.tga'): continue
        if (s.startswith('potion_bottle_') and s not in ('potion_bottle_empty', 'potion_bottle_drinkable', 'potion_bottle_splash')) \
           or (s.startswith('egg_') and s != 'egg_template') or (s.startswith('leather_') and ext == '.tga') \
           or s in ('watch_atlas', 'compass_atlas', 'clock_item', 'compass_item', 'map_mansion', 'map_monument') or s.startswith('skull_'):
            special.add(s); continue
        j = jitem(s)
        if j is None: continue
        save(limpa_item(j, s), out_path('items/' + fn)); mark('items/' + fn)
    def iput(name, im):
        p = bfile(basei, name)
        if not p.endswith('.tga'): im = limpa_item(im, name)  # nos .tga o alfa e mascara de cor: nao mexe
        save(im, out_path('items/' + os.path.basename(p))); mark('items/' + os.path.basename(p))
    def colorize(name, layers):
        """camadas (rel_java, pinta?): a cor de cada camada pintada e tirada do icone original do Bedrock"""
        p = bfile(basei, name)
        if not p: return False
        L = [(jimg(r), t) for r, t in layers]
        if any(x is None for x, _ in L): return False
        S = max(im.size[0] for im, _ in L); L = [(up(im, (S, S * im.size[1] // im.size[0])), t) for im, t in L]
        bA = arr(up(rgba(p), L[0][0].size)); cover = np.zeros(bA.shape[:2], bool); vis = []
        for im, t in reversed(L):
            a = arr(im); vis.append((a[..., 3] > 0) & ~cover); cover |= a[..., 3] > 0
        vis = vis[::-1]; res = Image.new('RGBA', L[0][0].size)
        for (im, t), v in zip(L, vis):
            if t:
                a = arr(im); m = v & (bA[..., 3] > 0)
                im = tint(im, np.minimum(mean_rgb(bA, m) / np.maximum(mean_rgb(a, m), 1), 4))
            res.alpha_composite(im)
        iput(name, res); return True
    for s in sorted(special):
        ok = False
        if s.startswith('potion_bottle_'):
            r = s[len('potion_bottle_'):]
            if r.startswith('splash'): ok = colorize(s, [('items/potion_overlay', True), ('items/potion_bottle_splash', False)])
            elif not r.startswith('lingering'): ok = colorize(s, [('items/potion_overlay', True), ('items/potion_bottle_drinkable', False)])
        elif s.startswith('egg_'):
            ok = colorize(s, [('items/spawn_egg', True), ('items/spawn_egg_overlay', True)])
        elif s.startswith('leather_'):
            part = s[len('leather_'):]; g = jimg('items/leather_' + part); ov = jimg('items/leather_%s_overlay' % part)
            if g:
                if ov: g, ov = match(g, ov)
                comp = g.copy()
                if ov: comp.alpha_composite(ov)
                a = arr(comp); ga = arr(g)[..., 3] > 0
                if ov: a[..., 3] = np.where(arr(ov)[..., 3] > 0, 3, np.where(ga, 255, 0))
                else:
                    ba = arr(up(rgba(bfile(basei, s)), g.size))[..., 3]; a[..., 3] = np.where(ga, np.where(ba > 0, ba, 255), 0)
                iput(s, img(a)); ok = True
        elif s in ('watch_atlas', 'clock_item', 'compass_atlas', 'compass_item'):
            src, n = ('clock', 64) if s in ('watch_atlas', 'clock_item') else ('compass', 32)
            j = jimg('items/' + src, ff=False)
            if j is not None:
                w = j.size[0]; frames = max(1, j.size[1] // w)
                if s.endswith('_item'): iput(s, j.crop((0, 0, w, w)))
                else:  # o jogo divide o atlas em 64 (relogio) / 32 (bussola) quadros
                    c = Image.new('RGBA', (w, w * n))
                    for i in range(n):
                        f = (i * frames) // n; c.paste(j.crop((0, f * w, w, (f + 1) * w)), (0, i * w))
                    iput(s, c)
                ok = True
        elif s.startswith('skull_'):
            ent = {'skull_zombie': 'entity/zombie/zombie', 'skull_skeleton': 'entity/skeleton/skeleton', 'skull_wither': 'entity/skeleton/wither_skeleton',
                   'skull_creeper': 'entity/creeper/creeper', 'skull_steve': 'entity/steve'}.get(s)
            j = jimg(ent) if ent else None
            if j is not None:
                u = j.size[0] / 64; face = j.crop((int(8*u), int(8*u), int(16*u), int(16*u)))
                if s == 'skull_steve' and j.size[0] == j.size[1]:
                    hat = j.crop((int(40*u), int(8*u), int(48*u), int(16*u))); face.alpha_composite(hat)
                bo = rgba(bfile(basei, s)); S = max(bo.size[0], face.size[0] * 16 // 9); b = arr(up(bo, (S, S)))
                ys, xs = np.nonzero(b[..., 3] > 0)
                if len(xs):
                    x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
                    b[y0:y1, x0:x1] = arr(face.resize((x1 - x0, y1 - y0), Image.NEAREST)); iput(s, img(b)); ok = True
        if not ok and s not in ('egg_npc', 'egg_null') and not s.startswith('potion_bottle_lingering') and s not in ('map_mansion', 'map_monument'):
            notas.append('item sem equivalente no pack, ficou original: ' + s)

    # =========================================================== PARTICULAS (celula = a maior resolucao encontrada)
    pp = bfile(os.path.join(BT, 'particle'), 'particles'); jpart = jimg('particle/particles', ff=False)
    if pp and jpart:
        bo = rgba(pp); cb = bo.size[0] // 16; cj = jpart.size[0] // 16; c = max(cb, cj)
        out = arr8(up(bo, (16 * c, 16 * c))); ja = arr8(up(jpart, (16 * c, jpart.size[1] * c // cj)))
        rows = min(16, ja.shape[0] // c)
        for r in range(rows):
            for q in range(16):
                cell = ja[r*c:(r+1)*c, q*c:(q+1)*c]
                if (cell[..., 3] > 0).any(): out[r*c:(r+1)*c, q*c:(q+1)*c] = cell
        save(img(out), out_path('particle/' + os.path.basename(pp))); mark('particle/particles')

    # =========================================================== QUADROS
    kp = bfile(os.path.join(BT, 'painting'), 'kz'); jk = jimg('painting/paintings_kristoffer_zetterstrand', ff=False)
    if kp and jk:
        bo = rgba(kp); S = max(bo.size[0], jk.size[0]); out = arr8(up(bo, (S, S))); ja = arr8(up(jk, (S, S))); t = S // 16
        for y in range(16):
            for x in range(16):
                cell = ja[y*t:(y+1)*t, x*t:(x+1)*t]
                if (cell[..., 3] > 0).any(): out[y*t:(y+1)*t, x*t:(x+1)*t] = cell
        save(img(out), out_path('painting/' + os.path.basename(kp))); mark('painting/kz')

    # =========================================================== AMBIENTE, MISC, MAPA, CORES
    for rel, src in (('environment/clouds', 'environment/clouds'), ('environment/end_sky', 'environment/end_sky'),
                     ('environment/moon_phases', 'environment/moon_phases'), ('environment/rain', 'environment/rain'),
                     ('environment/snow', 'environment/snow'), ('environment/sun', 'environment/sun'),
                     ('misc/enchanted_item_glint', 'misc/enchanted_item_glint'), ('misc/pumpkinblur', 'misc/pumpkinblur'),
                     ('map/map_background', 'map/map_background')):
        p = bfile(BT, rel); j = jimg(src)
        if p and j and same_aspect(j, Image.open(p)): put(p, j, os.path.dirname(rel))
    for i in range(10):
        p = bfile(BT, 'environment/destroy_stage_%d' % i); j = jimg('blocks/destroy_stage_%d' % i)
        if p and j: put(p, j, 'environment')
    p = bfile(BT, 'map/map_icons'); j = jimg('map/map_icons', ff=False)
    if p and j:
        bo = rgba(p); cb = bo.size[0] // 4; cj = j.size[0] // 4; c = max(cb, cj)
        out = arr(up(bo, (4 * c, 4 * c))); ja = arr(up(j, (4 * c, j.size[1] * c // cj)))
        for r in range(min(4, ja.shape[0] // c)):
            for q in range(4):
                cell = ja[r*c:(r+1)*c, q*c:(q+1)*c]
                if (cell[..., 3] > 0).any(): out[r*c:(r+1)*c, q*c:(q+1)*c] = cell
        put(p, img(out), 'map')
    for rel, srcs in (('colormap/grass', ['textures/colormap/grass']), ('colormap/foliage', ['textures/colormap/foliage']),
                      ('colormap/swamp_grass', ['mcpatcher/colormap/swampgrass']), ('colormap/swamp_foliage', ['mcpatcher/colormap/swampfoliage']),
                      ('colormap/evergreen', ['mcpatcher/colormap/pine']), ('colormap/birch', ['mcpatcher/colormap/birch'])):
        p = bfile(BT, rel)
        for s_ in srcs:
            f = os.path.join(raiz, s_ + '.png')
            if p and os.path.exists(f) and Image.open(f).size == Image.open(p).size: put(p, rgba(f), 'colormap'); break

    # =========================================================== ICONES DE EFEITO (inventory.png)
    inv = jimg('gui/container/inventory')
    med = os.path.join(BT, 'gui/newgui/mob_effects')
    if inv is not None and os.path.isdir(med):
        k = inv.size[0] / 256
        for name, (cx, cy) in POTION_ICON.items():
            p = bfile(med, name + '_effect')
            if not p: continue
            x0, y0 = int(cx * 18 * k), int((198 + cy * 18) * k)
            ic = inv.crop((x0, y0, x0 + int(18 * k), y0 + int(18 * k)))
            if (arr(ic)[..., 3] > 0).any(): put(p, ic, 'gui/newgui/mob_effects')

    # =========================================================== INTERFACE (resolucao do pack + ajuste dos JSON da interface)
    gd = os.path.join(BT, 'gui'); ui_factor = {}
    jic = jimg('gui/icons', ff=False)
    if jic is not None:
        bo = rgba(os.path.join(gd, 'icons.png')); k = max(1, -(-jic.size[0] // 256)); S = 256 * k
        b = arr(up(bo, (S, S))); ja = arr(jic.resize((S, S), Image.NEAREST) if jic.size[0] != S else jic); out = b.copy()
        for gy in range(6):  # grade 9x9 de vida/armadura/fome/bolhas: troca a celula inteira
            for gx in range(27):
                x0, y0 = (16 + gx * 9) * k, gy * 9 * k; x1, y1 = x0 + 9 * k, y0 + 9 * k
                if (ja[y0:y1, x0:x1, 3] > 0).any(): out[y0:y1, x0:x1] = ja[y0:y1, x0:x1]
        grid = np.zeros(out.shape[:2], bool); grid[0:54*k, 16*k:259*k] = True
        m = (ja[..., 3] > 0) & ~grid; out[m] = ja[m]
        save(img(out), out_path('gui/icons.png')); mark('gui/icons')
        ui_factor['textures/gui/icons'] = k
    jw = jimg('gui/widgets', ff=False)
    if jw is not None:
        bo = rgba(os.path.join(gd, 'gui.png')); k = max(1, -(-jw.size[0] // 256)); S = 256 * k
        out = arr(up(bo, (S, S))); ja = arr(jw.resize((S, S), Image.NEAREST) if jw.size[0] != S else jw)
        for (x0, y0, x1, y1) in [(0, 0, 182, 22), (0, 22, 24, 46), (0, 46, 200, 106)]:
            out[y0*k:y1*k, x0*k:x1*k] = ja[y0*k:y1*k, x0*k:x1*k]
        save(img(out), out_path('gui/gui.png')); mark('gui/gui')
        ui_factor['textures/gui/gui'] = k
    j = jimg('gui/options_background')
    if j is not None: save(j, out_path('gui/background.png')); mark('gui/background')
    # gui.png/icons.png e os JSON da interface sempre saem juntos e coerentes (evita misturar com um pack aplicado antes)
    for t, f in (('textures/gui/icons', 'icons.png'), ('textures/gui/gui', 'gui.png')):
        if t not in ui_factor:
            PK.put(out_path('gui/' + f), open(os.path.join(gd, f), 'rb').read()); ui_factor[t] = 1
    n, files, avisos = scale_ui(os.path.join(BASE, 'ui'), ui_factor, os.path.join(OUT, 'ui'), escrever=lambda f, b: PK.put(os.path.join(OUT, 'ui', f), b))
    if max(ui_factor.values()) > 1:
        notas.append('interface em alta resolucao (%s): %d medidas ajustadas em %s' % (
            ', '.join('%s %dx' % (os.path.basename(t), k_) for t, k_ in ui_factor.items()), n, ', '.join(files)))
    notas.extend(avisos)

    # =========================================================== FONTE
    fo = os.path.join(OUT, 'font')
    ja = jimg('font/ascii', ff=False)
    if ja is not None:
        bo = rgba(os.path.join(BASE, 'font/default8.png')); S = max(bo.size[0], ja.size[0]); c = S // 16
        b = arr(up(bo, (S, S))); nf = arr(up(ja, (S, S)))
        for cy in range(16):  # caracteres que o pack nao tem (acentos) ficam os do jogo
            for cx in range(16):
                sl = (slice(cy*c, (cy+1)*c), slice(cx*c, (cx+1)*c))
                if not (nf[sl][..., 3] > 0).any(): nf[sl] = b[sl]
        save(img(nf), os.path.join(fo, 'default8.png')); mark('font/default8')
    j = jimg('font/ascii_sga', ff=False)
    if j is not None: save(j, os.path.join(fo, 'ascii_sga.png')); mark('font/ascii_sga')
    glyphs = set(open(os.path.join(BASE, 'font/glyphs.txt')).read().split())
    for i in range(256):
        j = jimg('font/unicode_page_%02x' % i, ff=False)
        if j is not None and 'glyph_%02X' % i in glyphs and j.size[0] == j.size[1]:
            save(j, os.path.join(fo, 'glyph_%02X.png' % i)); mark('font/glyph_%02X' % i)

    # =========================================================== JSON, manifest, pacote
    PK.put(out_path('flipbook_textures.json'), json.dumps(fb, indent=1).encode())
    # nome = o do pack original; descricao = marca do conversor + descricao original do pack.mcmeta
    desc_orig = ''
    for cand in (os.path.join(raiz, '..', '..', 'pack.mcmeta'), os.path.join(raiz, '..', 'pack.mcmeta')):
        if os.path.exists(cand):
            try:
                d = json.loads(open(cand, 'rb').read().decode('utf-8-sig', 'ignore')).get('pack', {}).get('description', '')
                if isinstance(d, dict): d = d.get('text', '')
                if isinstance(d, list): d = ''.join(x if isinstance(x, str) else x.get('text', '') for x in d)
                desc_orig = str(d).strip()
            except Exception: pass
            break
    desc = '(Conversion tool by Smash Group)' + (' | ' + desc_orig if desc_orig else '')
    PK.put(os.path.join(OUT, 'manifest.json'), json.dumps({"format_version": 1, "header": {"description": desc, "name": titulo + ' - 1.1.5', "uuid": str(uuid.uuid4()),
               "version": [1, 0, 0], "min_engine_version": [1, 1, 0]},
               "modules": [{"description": desc, "type": "resources", "uuid": str(uuid.uuid4()), "version": [1, 0, 0]}]},
              indent=1).encode())
    for cand in (os.path.join(raiz, '..', '..', 'pack.png'), os.path.join(raiz, '..', 'pack.png'), os.path.join(raiz, 'pack.png')):
        if os.path.exists(cand): save(rgba(cand), os.path.join(OUT, 'pack_icon.png')); break
    avis = []
    z = os.path.join(saida, '%s - %s.zip' % (titulo_arq, alvo))
    # limites de memoria de video do jogo (atlas de blocos/itens e animacoes): evita fechar ao carregar
    import limites
    lim = limites.limitar(PK.arq, len(os.listdir(os.path.join(BT, 'blocks'))), len(os.listdir(os.path.join(BT, 'items'))))
    avis.extend(lim)
    # ceu do OptiFine/MCPatcher -> skybox por shader (so a 1.1.5 aceita shader no pack)
    if alvo == '1.1.5':
        try:
            import skybox
            k_sol = 'textures/environment/sun.png'
            sol = Image.open(io.BytesIO(PK.arq[k_sol])) if k_sol in PK.arq else (Image.open(os.path.join(BT, 'environment', 'sun.png')) if os.path.exists(os.path.join(BT, 'environment', 'sun.png')) else None)
            k_lua = 'textures/environment/moon_phases.png'
            lua = Image.open(io.BytesIO(PK.arq[k_lua])) if k_lua in PK.arq else (Image.open(os.path.join(BT, 'environment', 'moon_phases.png')) if os.path.exists(os.path.join(BT, 'environment', 'moon_phases.png')) else None)
            ceu = skybox.converter_ceu(os.path.dirname(os.path.dirname(raiz)), sol, lua)
            if ceu:
                nota_ceu = ceu.pop('_nota')
                for k_, v_ in ceu.items():
                    if hasattr(v_, 'save'): b_ = io.BytesIO(); v_.save(b_, format='PNG'); v_ = b_.getvalue()
                    elif isinstance(v_, str): v_ = v_.encode()
                    PK.arq[k_] = v_
                # com skybox as nuvens do jogo somem (como no OptiFine com ceu proprio)
                b_ = io.BytesIO(); Image.new('RGBA', (256, 256), (255, 255, 255, 0)).save(b_, format='PNG')
                PK.arq['textures/environment/clouds.png'] = b_.getvalue()
                nota_ceu += '; nuvens do jogo invisiveis'
                notas.append(nota_ceu); print('CEU: ' + nota_ceu)
        except Exception as e_:
            avis.append('nao foi possivel converter o ceu do OptiFine: %s' % e_)
    if alvo == '0.15.10':
        import conv015
        arq015, troc, pul = conv015.montar(PK.arq, os.path.join(HERE, 'base015'), titulo, desc)
        with zipfile.ZipFile(z, 'w') as zf:
            for n_ in sorted(arq015, key=lambda n: (n not in ('resources.json', 'pack_icon.png'), n)):
                zf.writestr(n_, arq015[n_], zipfile.ZIP_STORED if n_.endswith('.png') else zipfile.ZIP_DEFLATED)
        notas.append('MCPE 0.15.10: %d texturas do pack no lugar das originais da 0.15' % len(troc))
        if pul: notas.append('0.15.10: formato diferente, ficou a original: ' + ', '.join(pul))
        print('VERSAO015: %d' % len(troc))
    else:
        PK.gravar_zip(z)
    PACOTE = None
    # relatorio
    from collections import Counter
    cnt = Counter(x.split('/')[0] if not x.startswith('gui/newgui') else 'efeitos' for x in done)
    falta = []
    for d in ('blocks', 'items', 'entity'):
        for r, _, fs in os.walk(os.path.join(BT, d)):
            for f in fs:
                rel = os.path.relpath(os.path.join(r, f), BT).replace('\\', '/')
                if rel not in done and os.path.splitext(rel)[0] not in done and f.endswith(('.png', '.tga')): falta.append(rel)
    with open(os.path.join(saida, '%s - %s - relatorio.txt' % (titulo_arq, alvo)), 'w', encoding='utf-8') as R:
        R.write('Versao: MCPE %s\n' % alvo); R.write('Pack: %s\nConvertidas: %d texturas (todas na resolucao original do pack)\n' % (nome, len(done)))
        for k_, v in sorted(cnt.items()): R.write('  %s: %d\n' % (k_, v))
        for a in avis: R.write('AVISO: ' + a + '\n')
        R.write('\n'); [R.write(n_ + '\n') for n_ in notas]
        R.write('\n--- Ficaram com a textura original do jogo (o pack nao tem) ---\n'); [R.write(f + '\n') for f in sorted(falta)]
    shutil.rmtree(tmp, ignore_errors=True)
    print('Convertidas: %d texturas na resolucao original' % len(done))
    for k_, v in sorted(cnt.items()): print('  %s: %d' % (k_, v))
    for a in avis: print('AVISO:', a)
    print('\nResource pack (.zip):', z); print('Relatorio:', os.path.join(saida, '%s - %s - relatorio.txt' % (titulo_arq, alvo)))
    return z, OUT

def aplicar(z, jogo):
    """copia texturas/fonte/ui do pack (.zip) para dentro do APK extraido (substitui as padrao)"""
    dst = os.path.join(jogo, 'assets', 'resource_packs', 'vanilla')
    if not os.path.isdir(dst): raise SystemExit('Pasta do jogo invalida (nao achei %s)' % dst)
    n = 0
    with zipfile.ZipFile(z) as zf:
        for nm in zf.namelist():
            if nm.split('/')[0] in ('textures', 'font', 'ui') and not nm.endswith('/'):
                d = os.path.join(dst, *nm.split('/')); os.makedirs(os.path.dirname(d), exist_ok=True)
                with open(d, 'wb') as fo_: fo_.write(zf.read(nm)); n += 1
    print('Aplicado na pasta do jogo: %d arquivos -> %s' % (n, dst))

if __name__ == '__main__':
    a = sys.argv[1:]; jogo = None; alvo = '1.1.5'
    if '--015' in a: a.remove('--015'); alvo = '0.15.10'
    if '--aplicar' in a:
        i = a.index('--aplicar'); jogo = a[i + 1]; del a[i:i + 2]
    if not a: print(__doc__); sys.exit(1)
    out = a[1] if len(a) > 1 else os.path.dirname(os.path.abspath(a[0]))
    os.makedirs(out, exist_ok=True); z, OUT = converter(a[0], out, alvo=alvo)
    if jogo and alvo == '1.1.5': aplicar(z, jogo)
