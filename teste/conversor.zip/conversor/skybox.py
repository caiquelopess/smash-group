# -*- coding: utf-8 -*-
"""Skybox para o MCPE 1.1.5 sem mexer na lib do jogo.

Como o jogo desenha o sol e a lua (lido na lib 1.1.5):
  - os dois sao o mesmo quadrado 1x1 no plano y=0 (+-0.5), posicionado pela matriz WORLD;
  - os dois usam o material "sun_moon" (materials/sky.material); o sol usa sun.png e a lua
    moon_phases.png; o tamanho da textura chega ao shader em TEXTURE_DIMENSIONS;
  - o sol so e desenhado quando esta a menos de 105 graus do zenite; a lua idem. Quando um
    some, o outro esta no ceu.

O pack troca o shader do sun_moon. sun.png e moon_phases.png viram o mesmo "atlas" (a lua tem
4 linhas de pixel a mais, para o shader saber qual dos dois esta sendo desenhado). Quando o sol
esta no ceu, o desenho do sol cobre a tela com a skybox; quando o sol se poe, o desenho da lua
faz isso. O disco do sol/lua e redesenhado pelo shader no lugar certo.

O ceu do OptiFine/MCPatcher (assets/minecraft/optifine/sky/world0 ou mcpatcher/sky/world0) tem
varias camadas que aparecem e somem conforme a hora. Elas sao "assadas" em alguns horarios
(quadros); o shader descobre a hora pela posicao do sol e mistura os dois quadros mais proximos.

Layout do cubo (igual ao do OptiFine), cada quadrado = uma face:
    [ baixo ][ cima  ][  sul  ]
    [ oeste ][ norte ][ leste ]
Atlas: C x R blocos de 3x2 faces (um por quadro) + uma linha extra: [sol][fases da lua (2 faces)].
"""
import os, re, json, math
import numpy as np
from PIL import Image

LAYOUT = {'baixo': (0, 0), 'cima': (1, 0), 'sul': (2, 0), 'oeste': (0, 1), 'norte': (1, 1), 'leste': (2, 1)}

# ------------------------------------------------------------------ material
def material_json():
    """materials/sky.material da 1.1.5 com o sun_moon trocado pelo shader da skybox."""
    stencil = lambda base, func, ref=2: {"states": ["EnableStencilTest"], "frontFace": {"stencilFunc": func},
                                         "backFace": {"stencilFunc": func}, "stencilRef": ref, "stencilReadMask": 255}
    m = {
        "sun_moon": {
            "states": ["DisableDepthWrite", "DisableAlphaWrite", "DisableCulling", "Blending"],
            # cor pre-multiplicada: rgb + destino*(1-alfa). Com alfa 0 vira soma, igual ao sol original
            "blendSrc": "One", "blendDst": "OneMinusSrcAlpha",
            "vertexShader": "shaders/smash_ceu.vertex",
            "vrGeometryShader": "shaders/uv.geometry",
            "fragmentShader": "shaders/smash_ceu.fragment",
            "vertexFields": [{"field": "Position"}, {"field": "UV0"}],
            "msaaSupport": "MSAA"
        },
        "sun_moon_below_water:sun_moon": stencil(None, "Equal"),
        "stars": {
            "states": ["DisableDepthWrite", "DisableAlphaWrite", "Blending"],
            "blendSrc": "OneMinusDestColor", "blendDst": "One",
            "vertexShader": "shaders/color.vertex", "vrGeometryShader": "shaders/color.geometry",
            "fragmentShader": "shaders/stars.fragment",
            "vertexFields": [{"field": "Position"}, {"field": "Color"}], "msaaSupport": "MSAA"
        },
        "stars_below_water:stars": stencil(None, "Equal"),
        "skyplane": {
            "states": ["DisableDepthWrite", "DisableAlphaWrite"],
            "vertexShader": "shaders/sky.vertex", "vrGeometryShader": "shaders/sky.geometry",
            "fragmentShader": "shaders/color.fragment",
            "vertexFields": [{"field": "Position"}, {"field": "Color"}], "msaaSupport": "MSAA"
        },
        "skyplane_below_water:skyplane": stencil(None, "NotEqual"),
        "end_sky": {
            "states": ["DisableDepthWrite", "DisableAlphaWrite"], "msaaSupport": "MSAA",
            "vertexShader": "shaders/uv_repeat.vertex", "vrGeometryShader": "shaders/uv.geometry",
            "fragmentShader": "shaders/texture_ccolor.fragment",
            "vertexFields": [{"field": "Position"}, {"field": "UV0"}],
            "samplerStates": [{"samplerIndex": 0, "textureWrap": "Repeat"}]
        }
    }
    return json.dumps(m, indent=2)

# ------------------------------------------------------------------ shaders
VERT = r'''// __multiversion__
// Smash Group - skybox (vertex). Gerado pelo conversor.
#if __VERSION__ >= 300
#define attribute in
#define varying out
#endif

#ifdef GL_FRAGMENT_PRECISION_HIGH
#define HP highp
#else
#define HP mediump
#endif

uniform MAT4 WORLDVIEWPROJ;
uniform MAT4 WORLD;
uniform vec4 CURRENT_COLOR;
uniform highp vec3 TEXTURE_DIMENSIONS;

attribute POS4 POSITION;
attribute vec2 TEXCOORD_0;

varying vec2 uv;
varying HP vec3 dirMundo;
varying HP vec3 dirLocal;
varying HP vec3 camLocal;
varying vec4 info;     // x = modo, y = quadro A, z = quadro B, w = mistura
varying vec2 fase;     // fase da lua (coluna, linha)

const vec2 DIM_SOL = vec2(%SW%, %SH%);
const vec2 DIM_LUA = vec2(%LW%, %LH%);

highp mat4 inv4(highp mat4 m) {
  highp float a00 = m[0][0], a01 = m[0][1], a02 = m[0][2], a03 = m[0][3];
  highp float a10 = m[1][0], a11 = m[1][1], a12 = m[1][2], a13 = m[1][3];
  highp float a20 = m[2][0], a21 = m[2][1], a22 = m[2][2], a23 = m[2][3];
  highp float a30 = m[3][0], a31 = m[3][1], a32 = m[3][2], a33 = m[3][3];
  highp float b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10;
  highp float b03 = a01 * a12 - a02 * a11, b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12;
  highp float b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30, b08 = a20 * a33 - a23 * a30;
  highp float b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;
  highp float d = 1.0 / (b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06);
  return mat4(
    (a11 * b11 - a12 * b10 + a13 * b09) * d, (a02 * b10 - a01 * b11 - a03 * b09) * d,
    (a31 * b05 - a32 * b04 + a33 * b03) * d, (a22 * b04 - a21 * b05 - a23 * b03) * d,
    (a12 * b08 - a10 * b11 - a13 * b07) * d, (a00 * b11 - a02 * b08 + a03 * b07) * d,
    (a32 * b02 - a30 * b05 - a33 * b01) * d, (a20 * b05 - a22 * b02 + a23 * b01) * d,
    (a10 * b10 - a11 * b08 + a13 * b06) * d, (a01 * b08 - a00 * b10 - a03 * b06) * d,
    (a30 * b04 - a31 * b02 + a33 * b00) * d, (a21 * b02 - a20 * b04 - a23 * b00) * d,
    (a11 * b07 - a10 * b09 - a12 * b06) * d, (a00 * b09 - a01 * b07 + a02 * b06) * d,
    (a31 * b01 - a30 * b03 - a32 * b00) * d, (a20 * b03 - a21 * b01 + a22 * b00) * d);
}

void main()
{
  uv = TEXCOORD_0;
  dirMundo = vec3(0.0); dirLocal = vec3(0.0); camLocal = vec3(0.0);
  info = vec4(0.0); fase = vec2(0.0);
  vec2 dim = TEXTURE_DIMENSIONS.xy;
  bool sol = abs(dim.x - DIM_SOL.x) < 0.5 && abs(dim.y - DIM_SOL.y) < 0.5;
  bool lua = abs(dim.x - DIM_LUA.x) < 0.5 && abs(dim.y - DIM_LUA.y) < 0.5;
  if (!sol && !lua) {                                   // textura comum: igual ao jogo
    gl_Position = WORLDVIEWPROJ * POSITION;
    return;
  }
  highp mat4 inv = inv4(WORLDVIEWPROJ);
  highp vec4 hc = inv * vec4(0.0, 0.0, 1.0, 0.0);
  highp vec3 cam = hc.xyz / hc.w;                       // camera no espaco do quadrado
  highp mat3 w = mat3(WORLD[0].xyz, WORLD[1].xyz, WORLD[2].xyz);
  highp vec3 astro = normalize(w * (-cam));             // direcao do sol (ou da lua) no mundo
  vec3 dSol = lua ? -astro : astro;
  float h = 12.0 - atan(dSol.x, dSol.y) * 3.8197186;    // hora solar 0..24
  h = mod(h + 24.0, 24.0);
  float a = 0.0; float b = 0.0; float t = 0.0;
%QUADROS%
  bool tela;
  float modo;
  if (sol) {
    tela = CURRENT_COLOR.r > 0.999;                     // passadas de brilho extra: so o disco
    modo = tela ? 1.0 : 2.0;
  } else {
    float c = POSITION.x < 0.0 ? TEXCOORD_0.x * 4.0 - 1.0 : TEXCOORD_0.x * 4.0;
    float r = POSITION.z < 0.0 ? TEXCOORD_0.y * 2.0 : TEXCOORD_0.y * 2.0 - 1.0;
    fase = floor(vec2(c, r) + 0.5);
    tela = dSol.y < -0.2588;                            // sol abaixo de 105 graus: o jogo nao desenha o sol
    modo = tela ? 3.0 : 4.0;
  }
  info = vec4(modo, a, b, clamp(t, 0.0, 1.0));
  if (tela) {
    highp vec2 ndc = vec2(POSITION.x > 0.0 ? 1.0 : -1.0, POSITION.z > 0.0 ? 1.0 : -1.0);
    gl_Position = vec4(ndc, 0.9999, 1.0);
    highp vec4 p = inv * vec4(ndc, 0.0, 1.0);
    camLocal = cam;
    dirLocal = p.xyz / p.w - cam;
    dirMundo = w * dirLocal;
  } else {
    gl_Position = WORLDVIEWPROJ * POSITION;
    uv = vec2(0.5 - POSITION.x, POSITION.z + 0.5);
  }
}
'''

FRAG = r'''// __multiversion__
// Smash Group - skybox (fragment). Gerado pelo conversor.
#if __VERSION__ >= 300
#define varying in
#define texture2D texture
out vec4 FragColor;
#define gl_FragColor FragColor
#endif

#ifdef GL_FRAGMENT_PRECISION_HIGH
#define HP highp
#else
#define HP mediump
#endif

uniform vec4 CURRENT_COLOR;
uniform sampler2D TEXTURE_0;
uniform highp vec3 TEXTURE_DIMENSIONS;

varying vec2 uv;
varying HP vec3 dirMundo;
varying HP vec3 dirLocal;
varying HP vec3 camLocal;
varying vec4 info;
varying vec2 fase;

const float F = %F%;                        // lado de uma face em pixels
const float COLS = %COLS%;
const float G = %G%;                        // margem de cada face em pixels
const HP vec2 SOL = vec2(0.0, %SOLY%);       // celula do sol (em faces)
const HP vec2 LUA = vec2(1.0, %SOLY%);       // fases da lua: 2x1 faces, 4x2 fases

HP vec2 px(HP vec2 faces) { return faces * F / TEXTURE_DIMENSIONS.xy; }

HP vec2 cubo(HP vec3 d) {
  HP vec3 a = abs(d);
  HP vec2 cel; HP vec2 st;
  if (a.y >= a.x && a.y >= a.z) {
    if (d.y > 0.0) { cel = vec2(%CIMA%);  st = vec2(d.x, -d.z) / a.y; }
    else           { cel = vec2(%BAIXO%); st = vec2(d.x, d.z) / a.y; }
  } else if (a.x >= a.z) {
    if (d.x > 0.0) { cel = vec2(%LESTE%); st = vec2(d.z, -d.y) / a.x; }
    else           { cel = vec2(%OESTE%); st = vec2(-d.z, -d.y) / a.x; }
  } else {
    if (d.z > 0.0) { cel = vec2(%SUL%);   st = vec2(-d.x, -d.y) / a.z; }
    else           { cel = vec2(%NORTE%); st = vec2(d.x, -d.y) / a.z; }
  }
  return cel + (G + clamp(st * 0.5 + 0.5, 0.0, 1.0) * (F - 2.0 * G)) / F;
}

HP vec2 bloco(float k) {
  k = floor(k + 0.5);
  float r = floor(k / COLS);
  return vec2((k - r * COLS) * 3.0, r * 2.0);
}

vec4 disco(HP vec2 f, bool lua) {
  f = clamp(f, 0.0, 1.0);
  HP vec2 c = lua ? LUA + (fase * 0.5 * F + G + f * (0.5 * F - 2.0 * G)) / F : SOL + (G + f * (F - 2.0 * G)) / F;
  return CURRENT_COLOR * texture2D(TEXTURE_0, px(c));
}

void main()
{
  float modo = floor(info.x + 0.5);
  if (modo < 0.5) {                                   // textura comum
    vec4 l = CURRENT_COLOR * texture2D(TEXTURE_0, uv);
    gl_FragColor = vec4(l.rgb * l.a, 0.0);
    return;
  }
  if (modo == 2.0 || modo == 4.0) {                   // so o disco, no quadrado do jogo
    vec4 l = disco(uv, modo == 4.0);
    gl_FragColor = vec4(l.rgb * l.a, 0.0);
    return;
  }
  HP vec2 f = cubo(normalize(dirMundo));
  vec4 ca = texture2D(TEXTURE_0, px(bloco(info.y) + f));
  vec4 cb = texture2D(TEXTURE_0, px(bloco(info.z) + f));
  vec4 ceu = mix(ca, cb, info.w) * CURRENT_COLOR.a;
  if (abs(dirLocal.y) > 1e-6) {
    HP float t = -camLocal.y / dirLocal.y;
    HP vec3 p = camLocal + t * dirLocal;
    if (t > 0.0 && abs(p.x) < 0.5 && abs(p.z) < 0.5) {
      vec4 l = disco(vec2(0.5 - p.x, p.z + 0.5), modo == 3.0);
      ceu.rgb += l.rgb * l.a;
    }
  }
  gl_FragColor = ceu;
}
'''

def _hora_segmentos(horas):
    """if/else (GLSL ES 1.0 nao tem array constante) escolhendo os dois quadros da hora h."""
    n = len(horas)
    L = []
    h0, hn = horas[0], horas[-1]
    L.append('  if (h < %.4f) { a = %d.0; b = 0.0; t = (h + 24.0 - %.4f) / %.4f; }' % (h0, n - 1, hn, h0 + 24.0 - hn))
    for i in range(n - 1):
        L.append('  else if (h < %.4f) { a = %d.0; b = %d.0; t = (h - %.4f) / %.4f; }' % (horas[i + 1], i, i + 1, horas[i], horas[i + 1] - horas[i]))
    L.append('  else { a = %d.0; b = 0.0; t = (h - %.4f) / %.4f; }' % (n - 1, hn, h0 + 24.0 - hn))
    return '\n'.join(L)

LUA_EXTRA = 4   # linhas de pixel a mais no atlas da lua
def margem(F): return float(max(4, F // 32))

def shaders(horas, cols, rows, F):
    aw, ah = cols * 3 * F, (rows * 2 + 1) * F
    v = (VERT.replace('%QUADROS%', _hora_segmentos(horas)).replace('%SW%', '%.1f' % aw).replace('%SH%', '%.1f' % ah)
              .replace('%LW%', '%.1f' % aw).replace('%LH%', '%.1f' % (ah + LUA_EXTRA)))
    f = FRAG
    for k, (x, y) in LAYOUT.items():
        f = f.replace('%' + k.upper() + '%', '%.1f, %.1f' % (x, y))
    f = (f.replace('%F%', '%.1f' % F).replace('%COLS%', '%.1f' % cols)
          .replace('%G%', '%.1f' % margem(F)).replace('%SOLY%', '%.1f' % (rows * 2)))
    return v, f

# ------------------------------------------------------------------ tempo
def _celestial(t):
    """angulo celeste do Java (0..1, 0 = meio-dia) para a fracao do dia t (0 = 06:00)."""
    t = t % 1.0
    return t + ((1.0 - (math.cos(t * math.pi) + 1.0) / 2.0) - t) / 3.0

def solar_para_relogio(h_solar):
    """hora solar (a que o shader mede pelo sol) -> hora do relogio do OptiFine (hh:mm)."""
    c = ((h_solar - 12.0) / 24.0) % 1.0
    lo, hi = 0.0, 1.0
    for _ in range(40):
        m = (lo + hi) / 2
        if _celestial(m) < c: lo = m
        else: hi = m
    ticks = ((lo + hi) / 2 + 0.25) * 24000.0
    return (ticks / 1000.0 + 6.0) % 24.0

def _hora(s):
    s = s.replace('\\', '').strip()
    m = re.match(r'^(\d{1,2}):(\d{2})$', s)
    if not m: return None
    return (int(m.group(1)) + int(m.group(2)) / 60.0) % 24.0

def _dif(a, b):
    """distancia de a ate b andando para frente no relogio (0..24)."""
    return (b - a) % 24.0

def brilho(cam, h):
    """brilho de uma camada do OptiFine na hora h (relogio)."""
    sfi, efi, sfo, efo = cam.get('startFadeIn'), cam.get('endFadeIn'), cam.get('startFadeOut'), cam.get('endFadeOut')
    if sfi is None or efi is None or efo is None:
        return 1.0
    if sfo is None:
        sfo = (efo - _dif(sfi, efi)) % 24.0
    d_in, d_on, d_out = _dif(sfi, efi), _dif(efi, sfo), _dif(sfo, efo)
    x = _dif(sfi, h)
    if x < d_in: return x / d_in if d_in > 0 else 1.0
    x -= d_in
    if x < d_on: return 1.0
    x -= d_on
    if x < d_out: return 1.0 - x / d_out if d_out > 0 else 0.0
    return 0.0

# ------------------------------------------------------------------ leitura do pack Java
def achar_ceu(raiz):
    """pasta do ceu (world0) dentro do pack Java extraido, ou None."""
    for sub in ('optifine/sky/world0', 'mcpatcher/sky/world0'):
        p = os.path.join(raiz, 'assets', 'minecraft', *sub.split('/'))
        if os.path.isdir(p) and any(re.match(r'sky\d+\.properties$', n) for n in os.listdir(p)):
            return p
    return None

def _props(caminho):
    d = {}
    for linha in open(caminho, encoding='utf-8', errors='replace'):
        linha = linha.strip()
        if not linha or linha.startswith('#') or '=' not in linha: continue
        k, v = linha.split('=', 1)
        d[k.strip()] = v.strip()
    return d

def ler_camadas(pasta, raiz):
    nums = sorted(int(m.group(1)) for n in os.listdir(pasta) for m in [re.match(r'sky(\d+)\.properties$', n)] if m)
    camadas = []
    for n in nums:
        p = _props(os.path.join(pasta, 'sky%d.properties' % n))
        src = p.get('source', './sky%d.png' % n).replace('\\', '/')
        if src.startswith('./'): img = os.path.join(pasta, src[2:])
        elif ':' in src: ns, rel = src.split(':', 1); img = os.path.join(raiz, 'assets', ns, rel)
        elif src.startswith(('optifine/', 'mcpatcher/', 'textures/')): img = os.path.join(raiz, 'assets', 'minecraft', src)
        else: img = os.path.join(pasta, src)
        if not os.path.isfile(img): continue
        w = p.get('weather', 'clear').split()
        if 'clear' not in w: continue                       # camadas so de chuva ficam de fora
        if p.get('biomes') or p.get('heights'): pass        # o jogo nao informa bioma/altura ao shader: vale em todo lugar
        cam = {'n': n, 'img': img, 'blend': p.get('blend', 'add').lower(), 'rotate': p.get('rotate', 'true').lower() == 'true'}
        for k in ('startFadeIn', 'endFadeIn', 'startFadeOut', 'endFadeOut'):
            if k in p: cam[k] = _hora(p[k])
        camadas.append(cam)
    return camadas

# ------------------------------------------------------------------ quadros
def escolher_horas(camadas, k):
    """escolhe k horas solares onde as camadas mudam mais (programacao dinamica no ciclo de 24h)."""
    N = 96
    hs = [i * 24.0 / N for i in range(N)]
    W = np.array([[brilho(c, solar_para_relogio(h)) for c in camadas] for h in hs], dtype=np.float32)  # N x L
    if len(camadas) == 0 or float(np.ptp(W)) < 1e-6:
        return [0.0, 6.0, 12.0, 18.0][:max(1, min(k, 4))]
    W2 = np.concatenate([W, W, W[:1]])
    INF = 1e18
    custo = np.zeros((2 * N, N + 1), dtype=np.float64)   # custo[i, d] = erro de i ate i+d
    for i in range(2 * N):
        for d in range(2, N + 1):
            if i + d > 2 * N: custo[i, d] = INF; continue
            t = (np.arange(1, d) / float(d))[:, None]
            lin = W2[i] * (1 - t) + W2[i + d] * t
            custo[i, d] = float(((W2[i + 1:i + d] - lin) ** 2).sum())
    melhor = (INF, None)
    for s in range(0, N, 4):
        dp = np.full((k + 1, N), INF); de = np.full((k + 1, N), -1, dtype=int)
        dp[1, 0] = 0.0
        for q in range(2, k + 1):
            for j in range(1, N):
                c = dp[q - 1, :j] + custo[s + np.arange(j), j - np.arange(j)]
                a = int(np.argmin(c)); dp[q, j] = c[a]; de[q, j] = a
        fim = dp[k, :] + np.array([custo[s + j, N - j] if j > 0 else INF for j in range(N)])
        j = int(np.argmin(fim))
        if fim[j] < melhor[0]:
            pts, q = [], k
            while q >= 1 and j >= 0:
                pts.append(j); j = de[q, j]; q -= 1
            melhor = (float(fim.min()), sorted(float(((s + p) % N) * 24.0 / N) for p in pts))
    return melhor[1]

def _carregar(img, F):
    im = Image.open(img).convert('RGBA')
    if im.size != (3 * F, 2 * F):
        im = im.resize((3 * F, 2 * F), Image.BILINEAR)
    return np.asarray(im, dtype=np.float32) / 255.0

def assar(camadas, horas, F):
    """compoe as camadas em cada hora. Devolve lista de (rgb pre-multiplicado, alfa) em float32."""
    K = len(horas)
    rel = [solar_para_relogio(h) for h in horas]
    C = np.zeros((K, 2 * F, 3 * F, 3), dtype=np.float32)
    A = np.zeros((K, 2 * F, 3 * F, 1), dtype=np.float32)
    for cam in camadas:
        fs = [brilho(cam, r) for r in rel]
        if max(fs) <= 0.001: continue
        L = _carregar(cam['img'], F)
        rgb, a = L[..., :3], L[..., 3:4]
        for q, f in enumerate(fs):
            if f <= 0.001: continue
            b = cam['blend']
            if b in ('alpha', 'replace'):
                af = a * f if b == 'alpha' else np.full_like(a, f)
                C[q] = rgb * af + C[q] * (1 - af); A[q] = af + A[q] * (1 - af)
            elif b == 'screen':
                s = rgb * f
                C[q] = s + C[q] * (1 - s); A[q] = 1 - (1 - A[q]) * (1 - s.mean(axis=2, keepdims=True))
            elif b in ('multiply', 'burn', 'subtract', 'overlay'):
                continue                                    # escurecem o ceu: sem equivalente aqui
            else:                                           # add, dodge
                C[q] = C[q] + rgb * a * f
        del L
    return np.clip(C, 0, 1), np.clip(A, 0, 1)

def _redim(rgba, tam):
    """redimensiona cor e alfa separados: o PIL zera a cor de pixel transparente (e o ceu "add" e cor com alfa 0)."""
    rgb = np.asarray(Image.fromarray(np.ascontiguousarray(rgba[..., :3]), 'RGB').resize(tam, Image.BILINEAR))
    al = np.asarray(Image.fromarray(np.ascontiguousarray(rgba[..., 3]), 'L').resize(tam, Image.BILINEAR))
    return np.dstack([rgb, al])

def _com_margem(rgba, g, borda):
    """encolhe a imagem e poe margem de g px: 'borda' repete a beirada; senao fica transparente."""
    h, w = rgba.shape[:2]
    a = _redim(rgba, (w - 2 * g, h - 2 * g))
    return np.pad(a, ((g, g), (g, g), (0, 0)), mode='edge' if borda else 'constant')

def montar_atlas(C, A, sol_img, lua_img, F, cols):
    """devolve (sun.png, moon_phases.png, rows). Os dois tem o ceu, o sol e as fases da lua."""
    K = C.shape[0]
    g = int(margem(F))
    rows = (K + cols - 1) // cols
    W, H = cols * 3 * F, (rows * 2 + 1) * F
    out = np.zeros((H, W, 4), dtype=np.uint8)
    for q in range(K):
        x, y = (q % cols) * 3 * F, (q // cols) * 2 * F
        bloco = (np.concatenate([C[q], A[q]], axis=2) * 255 + 0.5).astype(np.uint8)
        for fy in range(2):
            for fx in range(3):
                out[y + fy * F:y + (fy + 1) * F, x + fx * F:x + (fx + 1) * F] = _com_margem(bloco[fy * F:(fy + 1) * F, fx * F:(fx + 1) * F], g, True)
    y0 = rows * 2 * F
    if sol_img is not None:
        s = _redim(np.asarray(sol_img.convert('RGBA')), (F, F))
        out[y0:y0 + F, :F] = _com_margem(s, g, False)
    if lua_img is not None:
        l = _redim(np.asarray(lua_img.convert('RGBA')), (2 * F, F))
        m = F // 2
        for i in range(8):
            cx, cy = (i % 4) * m, (i // 4) * m
            out[y0 + cy:y0 + cy + m, F + cx:F + cx + m] = _com_margem(np.ascontiguousarray(l[cy:cy + m, cx:cx + m]), g, False)
    sol = Image.fromarray(out, 'RGBA')
    lua = Image.fromarray(np.concatenate([out, np.zeros((LUA_EXTRA, W, 4), np.uint8)]), 'RGBA')
    return sol, lua, rows

def lado_face(n_quadros, maximo=4096):
    cols = min(4, n_quadros)
    rows = (n_quadros + cols - 1) // cols
    F = 512
    while F > 64 and (cols * 3 * F > maximo or (rows * 2 + 1) * F > maximo or cols * 3 * F * (rows * 2 + 1) * F > 3072 * 2048):
        F //= 2
    return F, cols

def converter_ceu(raiz, sol_img, lua_img=None, k=8):
    """pack Java extraido -> dict {caminho no pack 1.1.5: imagem/texto} ou None se nao tiver ceu."""
    pasta = achar_ceu(raiz)
    if not pasta: return None
    camadas = ler_camadas(pasta, raiz)
    if not camadas: return None
    for nome in ('sun.png', 'moon_phases.png'):
        p = os.path.join(pasta, nome)
        if os.path.isfile(p):
            if nome == 'sun.png': sol_img = Image.open(p)
            else: lua_img = Image.open(p)
    horas = escolher_horas(camadas, k)
    F, cols = lado_face(len(horas))
    C, A = assar(camadas, horas, F)
    sol, lua, rows = montar_atlas(C, A, sol_img, lua_img, F, cols)
    v, f = shaders(horas, cols, rows, F)
    rot = sum(1 for c in camadas if c['rotate'])
    nota = ('ceu do OptiFine convertido em skybox: %d camadas, %d horarios (%s), faces de %dpx'
            % (len(camadas), len(horas), ', '.join('%02d:%02d' % (int(solar_para_relogio(h)), int(round(solar_para_relogio(h) % 1 * 60)) % 60) for h in horas), F))
    if rot: nota += '; %d camadas que giravam com o sol ficam paradas' % rot
    return {'textures/environment/sun.png': sol, 'textures/environment/moon_phases.png': lua,
            'materials/sky.material': material_json(),
            'shaders/smash_ceu.vertex': v, 'shaders/smash_ceu.fragment': f, '_nota': nota}

# ------------------------------------------------------------------ diagnostico
def diagnostico(F=256, horas=(0, 3, 6, 9, 12, 15, 18, 21)):
    from PIL import ImageDraw, ImageFont
    try:
        fonte = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', F // 6)
        peq = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', F // 9)
    except Exception:
        fonte = peq = ImageFont.load_default()
    cores = {'cima': (90, 160, 255), 'baixo': (90, 60, 40), 'norte': (230, 60, 60), 'sul': (60, 200, 90),
             'leste': (255, 200, 40), 'oeste': (170, 80, 220)}
    K = len(horas); cols = min(4, K); rows = (K + cols - 1) // cols
    C = np.zeros((K, 2 * F, 3 * F, 3), np.float32); A = np.zeros((K, 2 * F, 3 * F, 1), np.float32)
    for q, h in enumerate(horas):
        im = Image.new('RGBA', (3 * F, 2 * F))
        d = ImageDraw.Draw(im)
        for nome, (x, y) in LAYOUT.items():
            x0, y0 = x * F, y * F
            d.rectangle([x0, y0, x0 + F - 1, y0 + F - 1], fill=cores[nome] + (255,))
            for g in range(0, F, F // 8):
                d.line([x0 + g, y0, x0 + g, y0 + F], fill=(0, 0, 0, 255), width=1)
                d.line([x0, y0 + g, x0 + F, y0 + g], fill=(0, 0, 0, 255), width=1)
            d.rectangle([x0, y0, x0 + F - 1, y0 + F - 1], outline=(255, 255, 255, 255), width=3)
            d.text((x0 + F // 2, y0 + F // 2 - F // 10), nome.upper(), font=fonte, fill=(255, 255, 255, 255), anchor='mm', stroke_width=3, stroke_fill=(0, 0, 0, 255))
            d.text((x0 + F // 2, y0 + F // 2 + F // 8), '%02dh' % h, font=peq, fill=(255, 255, 255, 255), anchor='mm', stroke_width=2, stroke_fill=(0, 0, 0, 255))
            d.polygon([(x0 + F // 2, y0 + 6), (x0 + F // 2 - F // 12, y0 + F // 9), (x0 + F // 2 + F // 12, y0 + F // 9)], fill=(255, 255, 255, 255))
        a = np.asarray(im, np.float32) / 255.0
        C[q] = a[..., :3] * 0.85; A[q] = a[..., 3:] * 0.85   # um pouco transparente: da para ver o ceu do jogo por tras
    sol = Image.new('RGBA', (32, 32), (0, 0, 0, 0)); ImageDraw.Draw(sol).rectangle([8, 8, 23, 23], fill=(255, 255, 160, 255))
    lua = Image.new('RGBA', (128, 64), (0, 0, 0, 0)); dl = ImageDraw.Draw(lua)
    for i in range(8):
        x, y = (i % 4) * 32, (i // 4) * 32
        dl.rectangle([x + 8, y + 8, x + 23, y + 23], fill=(200, 210, 255, 255)); dl.text((x + 12, y + 10), str(i), fill=(0, 0, 0, 255))
    sol_a, lua_a, rows = montar_atlas(C, A, sol, lua, F, cols)
    v, f = shaders([float(h) for h in horas], cols, rows, F)
    return {'textures/environment/sun.png': sol_a, 'textures/environment/moon_phases.png': lua_a,
            'materials/sky.material': material_json(),
            'shaders/smash_ceu.vertex': v, 'shaders/smash_ceu.fragment': f}
